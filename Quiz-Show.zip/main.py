#Display the Title

#Introduce the Game to the User
print("Welcome to Quiz Whiz Art History Trivia!")
print("")
print("The Game Will Consist of True or False Trivia Questions.")
print("")
print("Please Answer T for True and F For False")
print("")

#Setup Questions and Answers
questions = (
  'Q1. Georges Seurat was known for painting using the dot-technique',
  'Q2. Archangel Michael was often depicted with rainbow-colored wings',
  'Q3. The Mona Lisa, The Starry Night, and The Girl With The Pear Earring are among some of the most famous pieces of artwork in the world')
answers = ('T', 'F', 'T')

#Calculate the Number of Questions
numberOfQuestions = len(questions)

#Start from index = 0, iterate until the end of the list
# Keep track of which answers are correct with a score counter
index = 0
score = 0

while index < numberOfQuestions:
  # Ask the Question
  print("")
  print(f"Question: {questions[index]}")
  # Obtain the answer from the user
  userGuess = input("Answer: ")
  # Validate the input
  if userGuess == 'T' or userGuess == 'F':
    # Compare the answer to the correct answer
    if userGuess == answers[index]:
      score = score + 1
      index = index + 1
      print("Correct!")
    else:
      print("Incorrect, Please Choose Another Answer")

# Display the user's score
print("")
print(f"You got {score} out of {numberOfQuestions}")